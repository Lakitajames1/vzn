var _bcvma = _bcvma || [];
  _bcvma.push(["setAccountID", "5021647476238876565"]);
  _bcvma.push(["setParameter", "WebsiteDefID", "3156742262170387189"]);
  _bcvma.push(["setParameter", "InvitationDefID", "662610224802010840"]);
  _bcvma.push(["setParameter", "VisitName", ""]);
  _bcvma.push(["setParameter", "VisitPhone", ""]); // For authenticated customers, a variable can be set to pass in their phone numbers automatically for chat agent to identify customer
  _bcvma.push(["setParameter", "VisitEmail", ""]); // For authenticated customers, a variable can be set to pass in their email address automatically for chat agent to identify customer
  _bcvma.push(["setParameter", "VisitRef", ""]); // Any journey-specific values can be passed into here for triggering proactive invitatations
  _bcvma.push(["setParameter", "VisitInfo", ""]); // Any journey-specific values can be passed into here for triggering proactive invitatations
  _bcvma.push(["setParameter", "CustomUrl", ""]); 
  _bcvma.push(["setParameter", "WindowParameters", ""]);
  _bcvma.push(["pageViewed"]);
  var bcLoad = function(){
    if(window.bcLoaded) return; window.bcLoaded = true;
    var vms = document.createElement("script"); vms.type = "text/javascript"; vms.async = true;
    vms.src = ('https:'==document.location.protocol?'https://':'http://') + "vmss.boldchat.com/aid/5021647476238876565/bc.vms4/vms.js";
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(vms, s);
  };
  if(window.pageViewer && pageViewer.load) pageViewer.load();
  else if(window.addEventListener) window.addEventListener('load', bcLoad, false);
  else window.attachEvent('onload', bcLoad);