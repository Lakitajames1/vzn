// this function uses EC5 bind(), which is not present in IE8, so we need this polyfill
if (!Function.prototype.bind) {
  Function.prototype.bind = function(oThis) {
    if (typeof this !== 'function') {
      // closest thing possible to the ECMAScript 5
      // internal IsCallable function
      throw new TypeError('Function.prototype.bind - what is trying to be bound is not callable');
    }

    var aArgs   = Array.prototype.slice.call(arguments, 1),
        fToBind = this,
        fNOP    = function() {},
        fBound  = function() {
          return fToBind.apply(this instanceof fNOP && oThis ? this : oThis, aArgs.concat(Array.prototype.slice.call(arguments)));
        };

    fNOP.prototype = this.prototype;
    fBound.prototype = new fNOP();

    return fBound;
  };
}

;(function (factory) {

  /* jshint laxcomma:true, asi:true, debug:true, curly:false, camelcase:true, browser:true */
  /* global define */

  // Register as an anonymous AMD module if relevant, otherwise assume oldskool browser globals:
  if (typeof window.define === 'function' && define.amd)
    define(['jquery'], factory)
  else
    factory( jQuery )

})(function( $ ) {
  /* jshint laxcomma:true, asi:true, debug:true, curly:false, camelcase:true, browser:true */
    
  var AriaCarousel = function( el ) {
    var self = this;
    this.$el = $(el);
    this.anim = 0.75;
    this.quickAnim = 0.325;

    this.$el.each(function(index, instance) {
      self.enableControls(instance);
      self.setPositions(instance);
      self.setTabs(instance);
    });
  };
  
  AriaCarousel.prototype.setPositions = function(instance) {
    var $articles = $(instance).find('article[role=tabpanel]');
    var $current = $articles.filter('[aria-selected=true]');
    
    var $tabs = $(instance).find('ul[role=tablist] > li[role=presentation]');
    var $indicator = $(instance).find('.indicator');
    
    var currentIndex = $articles.index($current);
    
    var n
    for (n = 0; n <= currentIndex; n++) {
      $($articles[currentIndex-n]).css('left', -n*100 + '%');
    }
    
    for (n = 0; n <= ($articles.length-currentIndex); n++) {
      $($articles[currentIndex + n]).css('left', n*100 + '%');
    }
    
    if (currentIndex === ($articles.length-1)) {
      $articles.first().css('left', '100%');
    } else if (currentIndex === 0) {
      $articles.last().css('left', '-100%');
    }
    
    $indicator.css('left', ((100/$tabs.length)*currentIndex) + '%');
    
    $tabs.removeClass('selected').attr('aria-selected', false).eq(currentIndex).addClass('selected').attr('aria-selected', true);
    
  }
  
  AriaCarousel.prototype.setTabs = function(instance) {
    var self = this;
    var $tabs = $(instance).find('ul[role=tablist] > li[role=presentation]');
    $tabs.css('width', (100/$tabs.length) + "%");
    
    $(instance).find('ul[role=tablist]').prepend('<li class="indicator"><div><div></div></div></li>');
    this.resizeIndicator(instance);
    
    $(window).on('resize', function(e) {
      self.resizeIndicator(instance);
    });
    
    return $tabs;
  }
  
  AriaCarousel.prototype.resizeIndicator = function(instance) {
    var $tabs = $(instance).find('ul[role=tablist] > li[role=presentation]');
    $(instance).find('.indicator').css('width', $tabs.css('width'));
  }
  
  AriaCarousel.prototype.move = function(e, distance, loop) {
    console.log('Moving: ' + distance);
    console.log('Loop: ' + loop);
    var $el = $(e).hasClass('aria-carousel') ? $(e) : $(e.target).parents('.aria-carousel');
    var $articles = $el.find('article[role=tabpanel]');
    loop = typeof(loop) === 'undefined' ? -1 : loop;
    
    var $current = $articles.filter('[aria-selected=true]');
    var $replacement
    
    if (distance > 0) {
      $replacement = $current.next().length >= 1 ? $current.next() : $articles.first();
    } else if (distance < 0) {
      $replacement = $current.prev().length >= 1 ? $current.prev() : $articles.last();
    }
    
    var animLoop;
    
    if (loop === 0) {
      animLoop = loop;
    } else {
      animLoop = distance < 0 ? distance+1 : distance-1;
    }

    this.animate([ $current, $replacement ], animLoop);
    $current.attr('aria-selected', false);
    $replacement.attr('aria-selected', true);
  
    this.setPositions($el);
    
    return $articles;
  };
  
  
  AriaCarousel.prototype.enableControls = function(instance) {
    var self = this;
    $(instance).find('button.next').click( function(e) { this.move(e, 1); }.bind(this) );
    $(instance).find('button.prev').click( function(e) { this.move(e, -1); }.bind(this) );
    
    // IE8 
    if (typeof $.fn.hammer === 'function') {
			$(instance).find('> div').hammer().bind('swipeleft swiperight', function(e) {
				switch(e.type) {
				case 'swipeleft':
					self.move(e, 1);
					break;
				case 'swiperight':
					self.move(e, -1);
					break;
				}
			});
    }

    $(instance).find('a[role=tab]').each(function(index, tab) {
      $(tab).click(function(e) {
        var $articles = $(instance).find('article[role=tabpanel]');
        var currentIndex = $articles.index( $articles.filter('[aria-selected=true]') );
        console.log('Index: ' + index + ' / Current Index: ' + currentIndex);
        self.move(e, (index - currentIndex));
      });
      
      $(tab).keydown(function(e) {
        var $target = $(e.target);
        if ( (e.keyCode === 13) || (e.keyCode === 32) ) {
          e.preventDefault();
          $target.trigger('click'); 
        }
      });
    });
    
    $(instance).keydown(function(e) {
      switch(e.keyCode) {
      case 37:
        e.preventDefault();
        self.move(instance, -1);
        break;
      case 39:
        e.preventDefault();
        self.move(instance, 1);
        break;
      }
    });
    
    return self;
  }
  
  AriaCarousel.prototype.animate = function(articles, i) {

    var self = this;
    var duration = i === 0 ? this.anim : this.quickAnim;
    var type = i === 0 ? 'cubic-bezier(0.445, 0.05, 0.55, 0.95)' : 'linear';
    $(articles).each(function(index, article) {
      article.css('transition', 'left ' + duration + 's ' + type)
        .on('transitionend', function(e) {
          article.css('transition', '');
          article.unbind('transitionend');
          if (article.attr('aria-selected') === 'true') {
            if (i !== 0) {
              if(i < 0) self.move(e, i, i+1); else self.move(e, i, i-1);
            }
          }
        });
    });
  }
  
  return new AriaCarousel( '.aria-carousel' );
});