_satellite.pushAsyncScript(function(event, target, $variables){
  if(document.URL.split("/")[0]!="https:") {
	var g = document.createElement("script");
	var s = document.getElementsByTagName("script")[0]; 
	g.src = document.URL.split("/")[0]+"//www.three.co.uk/static/script/sitewideBoldchatMonitoring.js";      
	s.parentNode.insertBefore(g, s);
}
});
