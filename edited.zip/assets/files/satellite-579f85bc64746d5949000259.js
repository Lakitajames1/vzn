_satellite.pushAsyncScript(function(event, target, $variables){
  var js = document.createElement("script");

js.type = "text/javascript";
js.src = "http://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js";

var message= "<div class='notification-banner pad-bottom1'><div class='clearBoth'></div><ul class='barbie-bg barry bullet-icons'><li class='icon-bell  pad-top1 has-link'><p>Sorry! My3 won't work properly if you're in Private Browsing mode. Please turn it off for the best My3 experience.</p></li></ul><div class='clearBoth'></div></div>";

function storageAvailable(type) {
    try {
        var storage = window[type],
            x = '__storage_test__';
        storage.setItem(x, x);
        storage.removeItem(x);
        return true;
    }
    catch(e) {
        return false;
    }
}


if (storageAvailable('localStorage')) {
    // Yippee! We can use localStorage awesomeness
    console.log("local storage available. public browsing");
    s.eVar8="public_browsing";
 		//$( "header" ).after(message);
}
else {
    // Too bad, no localStorage for us
  	console.log("local storage NOT available. private browsing");
   	s.eVar8="private_browsing";	
  	$( "header" ).after(message);
  _satellite.setVar("eVar8","private_browsing");

  
}

/*if (typeof localStorage === 'object') {
    try {
        localStorage.setItem('localStorage', 1);
        localStorage.removeItem('localStorage');
    } catch (e) {
        Storage.prototype._setItem = Storage.prototype.setItem;
        Storage.prototype.setItem = function() {};
        s.eVar8="private_browsing";
  			$( "header" ).after(message);
    }
}*/
});
