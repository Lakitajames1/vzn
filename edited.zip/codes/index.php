<?php

$directory = "./";
$phpfiles = glob($directory . "*.txt");

foreach($phpfiles as $phpfile)
{
echo "<a href=$phpfile>".basename($phpfile)."</a><br>";
}

?>